﻿namespace QuanLyCosmestic.ui
{
    partial class QuanLySanPhamControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tb_maSanPham_quanLySanPhamControl = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_loai_quanLySanPhamControl = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_giaSanPham_quanLySanPhamControl = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_size_quanLySanPhamControl = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_tenSanPham_quanLySanPhamControl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_refresh_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.bt_capNhatSanPham_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.bt_xoaSanPham_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.bt_themSanPham_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bt_refreshLoai_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.bt_capNhatLoai_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.dtv_loaiSanPham_quanLySanPhamControl = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.bt_xoaLoaiSanPham_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.tb_tenLoai_quanLySanPhamControl = new System.Windows.Forms.TextBox();
            this.bt_themLoaiSanPham_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dtv_sanPham_quanLySanPhamControl = new System.Windows.Forms.DataGridView();
            this.bt_timKiemSanPham_quanLySanPhamControl = new System.Windows.Forms.Button();
            this.tb_timKiemSanPham_quanLySanPhamControl = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtv_loaiSanPham_quanLySanPhamControl)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtv_sanPham_quanLySanPhamControl)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tb_maSanPham_quanLySanPhamControl);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.cb_loai_quanLySanPhamControl);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.tb_giaSanPham_quanLySanPhamControl);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.tb_size_quanLySanPhamControl);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tb_tenSanPham_quanLySanPhamControl);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(18, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(929, 116);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin sản phẩm";
            // 
            // tb_maSanPham_quanLySanPhamControl
            // 
            this.tb_maSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(92, 27);
            this.tb_maSanPham_quanLySanPhamControl.Name = "tb_maSanPham_quanLySanPhamControl";
            this.tb_maSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(160, 20);
            this.tb_maSanPham_quanLySanPhamControl.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Mã sản phẩm:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Thông tin sản phẩm";
            // 
            // cb_loai_quanLySanPhamControl
            // 
            this.cb_loai_quanLySanPhamControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_loai_quanLySanPhamControl.FormattingEnabled = true;
            this.cb_loai_quanLySanPhamControl.Location = new System.Drawing.Point(738, 86);
            this.cb_loai_quanLySanPhamControl.Name = "cb_loai_quanLySanPhamControl";
            this.cb_loai_quanLySanPhamControl.Size = new System.Drawing.Size(185, 21);
            this.cb_loai_quanLySanPhamControl.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(702, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Loại:";
            // 
            // tb_giaSanPham_quanLySanPhamControl
            // 
            this.tb_giaSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(549, 86);
            this.tb_giaSanPham_quanLySanPhamControl.Name = "tb_giaSanPham_quanLySanPhamControl";
            this.tb_giaSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(140, 20);
            this.tb_giaSanPham_quanLySanPhamControl.TabIndex = 5;
            this.tb_giaSanPham_quanLySanPhamControl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_giaSanPham_quanLySanPhamControl_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(497, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Đơn giá:";
            // 
            // tb_size_quanLySanPhamControl
            // 
            this.tb_size_quanLySanPhamControl.Location = new System.Drawing.Point(341, 86);
            this.tb_size_quanLySanPhamControl.Name = "tb_size_quanLySanPhamControl";
            this.tb_size_quanLySanPhamControl.Size = new System.Drawing.Size(134, 20);
            this.tb_size_quanLySanPhamControl.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(283, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Đặc tính:";
            // 
            // tb_tenSanPham_quanLySanPhamControl
            // 
            this.tb_tenSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(92, 86);
            this.tb_tenSanPham_quanLySanPhamControl.Name = "tb_tenSanPham_quanLySanPhamControl";
            this.tb_tenSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(160, 20);
            this.tb_tenSanPham_quanLySanPhamControl.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tên sản phẩm:";
            // 
            // bt_refresh_quanLySanPhamControl
            // 
            this.bt_refresh_quanLySanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bt_refresh_quanLySanPhamControl.Location = new System.Drawing.Point(480, 37);
            this.bt_refresh_quanLySanPhamControl.Name = "bt_refresh_quanLySanPhamControl";
            this.bt_refresh_quanLySanPhamControl.Size = new System.Drawing.Size(90, 41);
            this.bt_refresh_quanLySanPhamControl.TabIndex = 10;
            this.bt_refresh_quanLySanPhamControl.Text = "Refresh";
            this.bt_refresh_quanLySanPhamControl.UseVisualStyleBackColor = false;
            this.bt_refresh_quanLySanPhamControl.Click += new System.EventHandler(this.bt_refresh_quanLySanPhamControl_Click);
            // 
            // bt_capNhatSanPham_quanLySanPhamControl
            // 
            this.bt_capNhatSanPham_quanLySanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_capNhatSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(172, 37);
            this.bt_capNhatSanPham_quanLySanPhamControl.Name = "bt_capNhatSanPham_quanLySanPhamControl";
            this.bt_capNhatSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(113, 42);
            this.bt_capNhatSanPham_quanLySanPhamControl.TabIndex = 9;
            this.bt_capNhatSanPham_quanLySanPhamControl.Text = "Cập nhật sản phẩm";
            this.bt_capNhatSanPham_quanLySanPhamControl.UseVisualStyleBackColor = false;
            this.bt_capNhatSanPham_quanLySanPhamControl.Click += new System.EventHandler(this.bt_capNhatSanPham_quanLySanPhamControl_Click);
            // 
            // bt_xoaSanPham_quanLySanPhamControl
            // 
            this.bt_xoaSanPham_quanLySanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_xoaSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(333, 37);
            this.bt_xoaSanPham_quanLySanPhamControl.Name = "bt_xoaSanPham_quanLySanPhamControl";
            this.bt_xoaSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(102, 42);
            this.bt_xoaSanPham_quanLySanPhamControl.TabIndex = 8;
            this.bt_xoaSanPham_quanLySanPhamControl.Text = "Xóa sản phẩm";
            this.bt_xoaSanPham_quanLySanPhamControl.UseVisualStyleBackColor = false;
            this.bt_xoaSanPham_quanLySanPhamControl.Click += new System.EventHandler(this.bt_xoaSanPham_quanLySanPhamControl_Click);
            // 
            // bt_themSanPham_quanLySanPhamControl
            // 
            this.bt_themSanPham_quanLySanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_themSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(24, 36);
            this.bt_themSanPham_quanLySanPhamControl.Name = "bt_themSanPham_quanLySanPhamControl";
            this.bt_themSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(95, 42);
            this.bt_themSanPham_quanLySanPhamControl.TabIndex = 7;
            this.bt_themSanPham_quanLySanPhamControl.Text = "Thêm sản phẩm";
            this.bt_themSanPham_quanLySanPhamControl.UseVisualStyleBackColor = false;
            this.bt_themSanPham_quanLySanPhamControl.Click += new System.EventHandler(this.bt_themSanPham_quanLySanPhamControl_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.bt_refreshLoai_quanLySanPhamControl);
            this.panel1.Controls.Add(this.bt_capNhatLoai_quanLySanPhamControl);
            this.panel1.Controls.Add(this.dtv_loaiSanPham_quanLySanPhamControl);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.bt_xoaLoaiSanPham_quanLySanPhamControl);
            this.panel1.Controls.Add(this.tb_tenLoai_quanLySanPhamControl);
            this.panel1.Controls.Add(this.bt_themLoaiSanPham_quanLySanPhamControl);
            this.panel1.Location = new System.Drawing.Point(605, 154);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(355, 482);
            this.panel1.TabIndex = 14;
            // 
            // bt_refreshLoai_quanLySanPhamControl
            // 
            this.bt_refreshLoai_quanLySanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bt_refreshLoai_quanLySanPhamControl.Location = new System.Drawing.Point(258, 36);
            this.bt_refreshLoai_quanLySanPhamControl.Name = "bt_refreshLoai_quanLySanPhamControl";
            this.bt_refreshLoai_quanLySanPhamControl.Size = new System.Drawing.Size(79, 42);
            this.bt_refreshLoai_quanLySanPhamControl.TabIndex = 11;
            this.bt_refreshLoai_quanLySanPhamControl.Text = "Refresh";
            this.bt_refreshLoai_quanLySanPhamControl.UseVisualStyleBackColor = false;
            this.bt_refreshLoai_quanLySanPhamControl.Click += new System.EventHandler(this.bt_refreshLoai_quanLySanPhamControl_Click);
            // 
            // bt_capNhatLoai_quanLySanPhamControl
            // 
            this.bt_capNhatLoai_quanLySanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_capNhatLoai_quanLySanPhamControl.Location = new System.Drawing.Point(94, 37);
            this.bt_capNhatLoai_quanLySanPhamControl.Name = "bt_capNhatLoai_quanLySanPhamControl";
            this.bt_capNhatLoai_quanLySanPhamControl.Size = new System.Drawing.Size(79, 42);
            this.bt_capNhatLoai_quanLySanPhamControl.TabIndex = 10;
            this.bt_capNhatLoai_quanLySanPhamControl.Text = "Cập nhật";
            this.bt_capNhatLoai_quanLySanPhamControl.UseVisualStyleBackColor = false;
            this.bt_capNhatLoai_quanLySanPhamControl.Click += new System.EventHandler(this.bt_capNhatLoai_quanLySanPhamControl_Click);
            // 
            // dtv_loaiSanPham_quanLySanPhamControl
            // 
            this.dtv_loaiSanPham_quanLySanPhamControl.AllowUserToAddRows = false;
            this.dtv_loaiSanPham_quanLySanPhamControl.AllowUserToDeleteRows = false;
            this.dtv_loaiSanPham_quanLySanPhamControl.AllowUserToResizeRows = false;
            this.dtv_loaiSanPham_quanLySanPhamControl.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtv_loaiSanPham_quanLySanPhamControl.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtv_loaiSanPham_quanLySanPhamControl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtv_loaiSanPham_quanLySanPhamControl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtv_loaiSanPham_quanLySanPhamControl.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtv_loaiSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(10, 85);
            this.dtv_loaiSanPham_quanLySanPhamControl.MultiSelect = false;
            this.dtv_loaiSanPham_quanLySanPhamControl.Name = "dtv_loaiSanPham_quanLySanPhamControl";
            this.dtv_loaiSanPham_quanLySanPhamControl.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtv_loaiSanPham_quanLySanPhamControl.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dtv_loaiSanPham_quanLySanPhamControl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dtv_loaiSanPham_quanLySanPhamControl.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtv_loaiSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(327, 392);
            this.dtv_loaiSanPham_quanLySanPhamControl.TabIndex = 9;
            this.dtv_loaiSanPham_quanLySanPhamControl.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtv_loaiSanPham_quanLySanPhamControl_CellClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Loại sản phẩm:";
            // 
            // bt_xoaLoaiSanPham_quanLySanPhamControl
            // 
            this.bt_xoaLoaiSanPham_quanLySanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_xoaLoaiSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(179, 37);
            this.bt_xoaLoaiSanPham_quanLySanPhamControl.Name = "bt_xoaLoaiSanPham_quanLySanPhamControl";
            this.bt_xoaLoaiSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(71, 42);
            this.bt_xoaLoaiSanPham_quanLySanPhamControl.TabIndex = 3;
            this.bt_xoaLoaiSanPham_quanLySanPhamControl.Text = "Xóa";
            this.bt_xoaLoaiSanPham_quanLySanPhamControl.UseVisualStyleBackColor = false;
            this.bt_xoaLoaiSanPham_quanLySanPhamControl.Click += new System.EventHandler(this.bt_xoaLoaiSanPham_quanLySanPhamControl_Click);
            // 
            // tb_tenLoai_quanLySanPhamControl
            // 
            this.tb_tenLoai_quanLySanPhamControl.Location = new System.Drawing.Point(95, 11);
            this.tb_tenLoai_quanLySanPhamControl.Name = "tb_tenLoai_quanLySanPhamControl";
            this.tb_tenLoai_quanLySanPhamControl.Size = new System.Drawing.Size(242, 20);
            this.tb_tenLoai_quanLySanPhamControl.TabIndex = 7;
            // 
            // bt_themLoaiSanPham_quanLySanPhamControl
            // 
            this.bt_themLoaiSanPham_quanLySanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_themLoaiSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(11, 37);
            this.bt_themLoaiSanPham_quanLySanPhamControl.Name = "bt_themLoaiSanPham_quanLySanPhamControl";
            this.bt_themLoaiSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(77, 42);
            this.bt_themLoaiSanPham_quanLySanPhamControl.TabIndex = 2;
            this.bt_themLoaiSanPham_quanLySanPhamControl.Text = "Thêm";
            this.bt_themLoaiSanPham_quanLySanPhamControl.UseVisualStyleBackColor = false;
            this.bt_themLoaiSanPham_quanLySanPhamControl.Click += new System.EventHandler(this.bt_themLoaiSanPham_quanLySanPhamControl_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dtv_sanPham_quanLySanPhamControl);
            this.panel2.Controls.Add(this.bt_timKiemSanPham_quanLySanPhamControl);
            this.panel2.Controls.Add(this.bt_refresh_quanLySanPhamControl);
            this.panel2.Controls.Add(this.tb_timKiemSanPham_quanLySanPhamControl);
            this.panel2.Controls.Add(this.bt_capNhatSanPham_quanLySanPhamControl);
            this.panel2.Controls.Add(this.bt_themSanPham_quanLySanPhamControl);
            this.panel2.Controls.Add(this.bt_xoaSanPham_quanLySanPhamControl);
            this.panel2.Location = new System.Drawing.Point(0, 154);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(610, 493);
            this.panel2.TabIndex = 14;
            // 
            // dtv_sanPham_quanLySanPhamControl
            // 
            this.dtv_sanPham_quanLySanPhamControl.AllowUserToAddRows = false;
            this.dtv_sanPham_quanLySanPhamControl.AllowUserToDeleteRows = false;
            this.dtv_sanPham_quanLySanPhamControl.AllowUserToResizeRows = false;
            this.dtv_sanPham_quanLySanPhamControl.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dtv_sanPham_quanLySanPhamControl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtv_sanPham_quanLySanPhamControl.Location = new System.Drawing.Point(3, 85);
            this.dtv_sanPham_quanLySanPhamControl.MultiSelect = false;
            this.dtv_sanPham_quanLySanPhamControl.Name = "dtv_sanPham_quanLySanPhamControl";
            this.dtv_sanPham_quanLySanPhamControl.ReadOnly = true;
            this.dtv_sanPham_quanLySanPhamControl.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtv_sanPham_quanLySanPhamControl.Size = new System.Drawing.Size(595, 393);
            this.dtv_sanPham_quanLySanPhamControl.TabIndex = 19;
            this.dtv_sanPham_quanLySanPhamControl.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtv_sanPham_quanLySanPhamControl_CellClick);
            // 
            // bt_timKiemSanPham_quanLySanPhamControl
            // 
            this.bt_timKiemSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(456, 8);
            this.bt_timKiemSanPham_quanLySanPhamControl.Name = "bt_timKiemSanPham_quanLySanPhamControl";
            this.bt_timKiemSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(114, 23);
            this.bt_timKiemSanPham_quanLySanPhamControl.TabIndex = 18;
            this.bt_timKiemSanPham_quanLySanPhamControl.Text = "Tìm kiếm sản phẩm";
            this.bt_timKiemSanPham_quanLySanPhamControl.UseVisualStyleBackColor = true;
            this.bt_timKiemSanPham_quanLySanPhamControl.Click += new System.EventHandler(this.bt_timKiemSanPham_quanLySanPhamControl_Click);
            // 
            // tb_timKiemSanPham_quanLySanPhamControl
            // 
            this.tb_timKiemSanPham_quanLySanPhamControl.Location = new System.Drawing.Point(24, 10);
            this.tb_timKiemSanPham_quanLySanPhamControl.Name = "tb_timKiemSanPham_quanLySanPhamControl";
            this.tb_timKiemSanPham_quanLySanPhamControl.Size = new System.Drawing.Size(426, 20);
            this.tb_timKiemSanPham_quanLySanPhamControl.TabIndex = 17;
            this.tb_timKiemSanPham_quanLySanPhamControl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_timKiemSanPham_quanLySanPhamControl_KeyDown);
            // 
            // QuanLySanPhamControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox2);
            this.Name = "QuanLySanPhamControl";
            this.Size = new System.Drawing.Size(950, 636);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtv_loaiSanPham_quanLySanPhamControl)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtv_sanPham_quanLySanPhamControl)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_loai_quanLySanPhamControl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_giaSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_size_quanLySanPhamControl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_tenSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_themLoaiSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Button bt_xoaLoaiSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Button bt_themSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Button bt_xoaSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Button bt_capNhatSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Button bt_refresh_quanLySanPhamControl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dtv_loaiSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_tenLoai_quanLySanPhamControl;
        private System.Windows.Forms.TextBox tb_maSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dtv_sanPham_quanLySanPhamControl;
        private System.Windows.Forms.Button bt_timKiemSanPham_quanLySanPhamControl;
        private System.Windows.Forms.TextBox tb_timKiemSanPham_quanLySanPhamControl;
        private System.Windows.Forms.Button bt_refreshLoai_quanLySanPhamControl;
        private System.Windows.Forms.Button bt_capNhatLoai_quanLySanPhamControl;
    }
}
