﻿namespace QuanLyCosmestic.ui
{
    partial class QuanLyKhachHangVaSuKienControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgv_khachHang_quanLyKhachHangVaSuKien = new System.Windows.Forms.DataGridView();
            this.bt_timKiem_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.tb_timKiemKhachHang_quanLyKhachHangVaSuKien = new System.Windows.Forms.TextBox();
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.bt_themKhachHang_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_diaChi_quanLyKhachHangVaSuKien = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_hoVaTen_quanLyKhachHangVaSuKien = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_sdt_quanLyKhachHangVaSuKien = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgv_suKien_quanLyKhachHangVaSuKien = new System.Windows.Forms.DataGridView();
            this.bt_timKiemSuKien_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.tb_timKiemSuKien_quanLyKhachHangVaSuKien = new System.Windows.Forms.TextBox();
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.bt_themSuKien_quanLyKhachHangVaSuKien = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_giamGia_quanLyKhachHangVaSuKien = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_tenSuKien_quanLyKhachHangVaControl = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_khachHang_quanLyKhachHangVaSuKien)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_suKien_quanLyKhachHangVaSuKien)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dgv_khachHang_quanLyKhachHangVaSuKien);
            this.panel1.Controls.Add(this.bt_timKiem_quanLyKhachHangVaSuKien);
            this.panel1.Controls.Add(this.tb_timKiemKhachHang_quanLyKhachHangVaSuKien);
            this.panel1.Controls.Add(this.bt_refreshKhachHang_quanLyKhachHangVaSuKien);
            this.panel1.Controls.Add(this.bt_xoaKhachHang_quanLyKhachHangVaSuKien);
            this.panel1.Controls.Add(this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien);
            this.panel1.Controls.Add(this.bt_themKhachHang_quanLyKhachHangVaSuKien);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(595, 636);
            this.panel1.TabIndex = 0;
            // 
            // dgv_khachHang_quanLyKhachHangVaSuKien
            // 
            this.dgv_khachHang_quanLyKhachHangVaSuKien.AllowUserToAddRows = false;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.AllowUserToDeleteRows = false;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.AllowUserToResizeRows = false;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(12, 236);
            this.dgv_khachHang_quanLyKhachHangVaSuKien.MultiSelect = false;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.Name = "dgv_khachHang_quanLyKhachHangVaSuKien";
            this.dgv_khachHang_quanLyKhachHangVaSuKien.ReadOnly = true;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(517, 380);
            this.dgv_khachHang_quanLyKhachHangVaSuKien.TabIndex = 7;
            this.dgv_khachHang_quanLyKhachHangVaSuKien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_khachHang_quanLyKhachHangVaSuKien_CellClick);
            // 
            // bt_timKiem_quanLyKhachHangVaSuKien
            // 
            this.bt_timKiem_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(454, 204);
            this.bt_timKiem_quanLyKhachHangVaSuKien.Name = "bt_timKiem_quanLyKhachHangVaSuKien";
            this.bt_timKiem_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(75, 23);
            this.bt_timKiem_quanLyKhachHangVaSuKien.TabIndex = 6;
            this.bt_timKiem_quanLyKhachHangVaSuKien.Text = "Tìm kiếm";
            this.bt_timKiem_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = true;
            this.bt_timKiem_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_timKiem_quanLyKhachHangVaSuKien_Click);
            // 
            // tb_timKiemKhachHang_quanLyKhachHangVaSuKien
            // 
            this.tb_timKiemKhachHang_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(12, 207);
            this.tb_timKiemKhachHang_quanLyKhachHangVaSuKien.Name = "tb_timKiemKhachHang_quanLyKhachHangVaSuKien";
            this.tb_timKiemKhachHang_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(429, 20);
            this.tb_timKiemKhachHang_quanLyKhachHangVaSuKien.TabIndex = 5;
            this.tb_timKiemKhachHang_quanLyKhachHangVaSuKien.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_timKiemKhachHang_quanLyKhachHangVaSuKien_KeyDown);
            // 
            // bt_refreshKhachHang_quanLyKhachHangVaSuKien
            // 
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(348, 156);
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien.Name = "bt_refreshKhachHang_quanLyKhachHangVaSuKien";
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(93, 35);
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien.TabIndex = 4;
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien.Text = "Refresh";
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = false;
            this.bt_refreshKhachHang_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_refreshKhachHang_quanLyKhachHangVaSuKien_Click);
            // 
            // bt_xoaKhachHang_quanLyKhachHangVaSuKien
            // 
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(239, 156);
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien.Name = "bt_xoaKhachHang_quanLyKhachHangVaSuKien";
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(93, 35);
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien.TabIndex = 3;
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien.Text = "Xóa";
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = false;
            this.bt_xoaKhachHang_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_xoaKhachHang_quanLyKhachHangVaSuKien_Click);
            // 
            // bt_capNhatKhachHang_quanLyKhachHangVaSuKien
            // 
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(129, 156);
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien.Name = "bt_capNhatKhachHang_quanLyKhachHangVaSuKien";
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(93, 35);
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien.TabIndex = 2;
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien.Text = "Cập nhật";
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = false;
            this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_capNhatKhachHang_quanLyKhachHangVaSuKien_Click);
            // 
            // bt_themKhachHang_quanLyKhachHangVaSuKien
            // 
            this.bt_themKhachHang_quanLyKhachHangVaSuKien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_themKhachHang_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(12, 156);
            this.bt_themKhachHang_quanLyKhachHangVaSuKien.Name = "bt_themKhachHang_quanLyKhachHangVaSuKien";
            this.bt_themKhachHang_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(93, 35);
            this.bt_themKhachHang_quanLyKhachHangVaSuKien.TabIndex = 1;
            this.bt_themKhachHang_quanLyKhachHangVaSuKien.Text = "Thêm";
            this.bt_themKhachHang_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = false;
            this.bt_themKhachHang_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_themKhachHang_quanLyKhachHangVaSanPham_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tb_diaChi_quanLyKhachHangVaSuKien);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tb_hoVaTen_quanLyKhachHangVaSuKien);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tb_sdt_quanLyKhachHangVaSuKien);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(517, 115);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin khách hàng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Thông tin khách hàng";
            // 
            // tb_diaChi_quanLyKhachHangVaSuKien
            // 
            this.tb_diaChi_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(114, 73);
            this.tb_diaChi_quanLyKhachHangVaSuKien.Name = "tb_diaChi_quanLyKhachHangVaSuKien";
            this.tb_diaChi_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(315, 20);
            this.tb_diaChi_quanLyKhachHangVaSuKien.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Địa chỉ:";
            // 
            // tb_hoVaTen_quanLyKhachHangVaSuKien
            // 
            this.tb_hoVaTen_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(114, 49);
            this.tb_hoVaTen_quanLyKhachHangVaSuKien.Name = "tb_hoVaTen_quanLyKhachHangVaSuKien";
            this.tb_hoVaTen_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(315, 20);
            this.tb_hoVaTen_quanLyKhachHangVaSuKien.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Họ tên khách hàng:";
            // 
            // tb_sdt_quanLyKhachHangVaSuKien
            // 
            this.tb_sdt_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(114, 23);
            this.tb_sdt_quanLyKhachHangVaSuKien.Name = "tb_sdt_quanLyKhachHangVaSuKien";
            this.tb_sdt_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(315, 20);
            this.tb_sdt_quanLyKhachHangVaSuKien.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Số điện thoại:";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dgv_suKien_quanLyKhachHangVaSuKien);
            this.panel2.Controls.Add(this.bt_timKiemSuKien_quanLyKhachHangVaSuKien);
            this.panel2.Controls.Add(this.tb_timKiemSuKien_quanLyKhachHangVaSuKien);
            this.panel2.Controls.Add(this.bt_refreshSuKien_quanLyKhachHangVaSuKien);
            this.panel2.Controls.Add(this.bt_xoaSuKien_quanLyKhachHangVaSuKien);
            this.panel2.Controls.Add(this.bt_capNhatSuKien_quanLyKhachHangVaSuKien);
            this.panel2.Controls.Add(this.bt_themSuKien_quanLyKhachHangVaSuKien);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(547, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(403, 636);
            this.panel2.TabIndex = 1;
            // 
            // dgv_suKien_quanLyKhachHangVaSuKien
            // 
            this.dgv_suKien_quanLyKhachHangVaSuKien.AllowUserToAddRows = false;
            this.dgv_suKien_quanLyKhachHangVaSuKien.AllowUserToDeleteRows = false;
            this.dgv_suKien_quanLyKhachHangVaSuKien.AllowUserToResizeRows = false;
            this.dgv_suKien_quanLyKhachHangVaSuKien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_suKien_quanLyKhachHangVaSuKien.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgv_suKien_quanLyKhachHangVaSuKien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_suKien_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(12, 236);
            this.dgv_suKien_quanLyKhachHangVaSuKien.MultiSelect = false;
            this.dgv_suKien_quanLyKhachHangVaSuKien.Name = "dgv_suKien_quanLyKhachHangVaSuKien";
            this.dgv_suKien_quanLyKhachHangVaSuKien.ReadOnly = true;
            this.dgv_suKien_quanLyKhachHangVaSuKien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_suKien_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(371, 379);
            this.dgv_suKien_quanLyKhachHangVaSuKien.TabIndex = 11;
            this.dgv_suKien_quanLyKhachHangVaSuKien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_suKien_quanLyKhachHangVaSuKien_CellClick);
            // 
            // bt_timKiemSuKien_quanLyKhachHangVaSuKien
            // 
            this.bt_timKiemSuKien_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(308, 210);
            this.bt_timKiemSuKien_quanLyKhachHangVaSuKien.Name = "bt_timKiemSuKien_quanLyKhachHangVaSuKien";
            this.bt_timKiemSuKien_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(75, 23);
            this.bt_timKiemSuKien_quanLyKhachHangVaSuKien.TabIndex = 12;
            this.bt_timKiemSuKien_quanLyKhachHangVaSuKien.Text = "Tìm kiếm";
            this.bt_timKiemSuKien_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = true;
            this.bt_timKiemSuKien_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_timKiemSuKien_quanLyKhachHangVaSuKien_Click);
            // 
            // tb_timKiemSuKien_quanLyKhachHangVaSuKien
            // 
            this.tb_timKiemSuKien_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(12, 212);
            this.tb_timKiemSuKien_quanLyKhachHangVaSuKien.Name = "tb_timKiemSuKien_quanLyKhachHangVaSuKien";
            this.tb_timKiemSuKien_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(283, 20);
            this.tb_timKiemSuKien_quanLyKhachHangVaSuKien.TabIndex = 17;
            this.tb_timKiemSuKien_quanLyKhachHangVaSuKien.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_timKiemSuKien_quanLyKhachHangVaSuKien_KeyDown);
            // 
            // bt_refreshSuKien_quanLyKhachHangVaSuKien
            // 
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(308, 169);
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien.Name = "bt_refreshSuKien_quanLyKhachHangVaSuKien";
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(75, 35);
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien.TabIndex = 13;
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien.Text = "Refresh";
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = false;
            this.bt_refreshSuKien_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_refreshSuKien_quanLyKhachHangVaSuKien_Click);
            // 
            // bt_xoaSuKien_quanLyKhachHangVaSuKien
            // 
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(220, 171);
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien.Name = "bt_xoaSuKien_quanLyKhachHangVaSuKien";
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(75, 35);
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien.TabIndex = 14;
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien.Text = "Xóa";
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = false;
            this.bt_xoaSuKien_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_xoaSuKien_quanLyKhachHangVaSuKien_Click);
            // 
            // bt_capNhatSuKien_quanLyKhachHangVaSuKien
            // 
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(114, 171);
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien.Name = "bt_capNhatSuKien_quanLyKhachHangVaSuKien";
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(75, 35);
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien.TabIndex = 15;
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien.Text = "Cập nhật";
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = false;
            this.bt_capNhatSuKien_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_capNhatSuKien_quanLyKhachHangVaSuKien_Click);
            // 
            // bt_themSuKien_quanLyKhachHangVaSuKien
            // 
            this.bt_themSuKien_quanLyKhachHangVaSuKien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_themSuKien_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(12, 171);
            this.bt_themSuKien_quanLyKhachHangVaSuKien.Name = "bt_themSuKien_quanLyKhachHangVaSuKien";
            this.bt_themSuKien_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(75, 35);
            this.bt_themSuKien_quanLyKhachHangVaSuKien.TabIndex = 16;
            this.bt_themSuKien_quanLyKhachHangVaSuKien.Text = "Thêm";
            this.bt_themSuKien_quanLyKhachHangVaSuKien.UseVisualStyleBackColor = false;
            this.bt_themSuKien_quanLyKhachHangVaSuKien.Click += new System.EventHandler(this.bt_themSuKien_quanLyKhachHangVaSuKien_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tb_giamGia_quanLyKhachHangVaSuKien);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.tb_tenSuKien_quanLyKhachHangVaControl);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(12, 17);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(371, 114);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin sự kiện";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Thông tin sự kiện";
            // 
            // tb_giamGia_quanLyKhachHangVaSuKien
            // 
            this.tb_giamGia_quanLyKhachHangVaSuKien.Location = new System.Drawing.Point(78, 55);
            this.tb_giamGia_quanLyKhachHangVaSuKien.Name = "tb_giamGia_quanLyKhachHangVaSuKien";
            this.tb_giamGia_quanLyKhachHangVaSuKien.Size = new System.Drawing.Size(110, 20);
            this.tb_giamGia_quanLyKhachHangVaSuKien.TabIndex = 7;
            this.tb_giamGia_quanLyKhachHangVaSuKien.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_giamGia_quanLyKhachHangVaControl_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Giảm giá:";
            // 
            // tb_tenSuKien_quanLyKhachHangVaControl
            // 
            this.tb_tenSuKien_quanLyKhachHangVaControl.Location = new System.Drawing.Point(78, 23);
            this.tb_tenSuKien_quanLyKhachHangVaControl.Name = "tb_tenSuKien_quanLyKhachHangVaControl";
            this.tb_tenSuKien_quanLyKhachHangVaControl.Size = new System.Drawing.Size(287, 20);
            this.tb_tenSuKien_quanLyKhachHangVaControl.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Tên sự kiện:";
            // 
            // QuanLyKhachHangVaSuKienControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "QuanLyKhachHangVaSuKienControl";
            this.Size = new System.Drawing.Size(950, 636);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_khachHang_quanLyKhachHangVaSuKien)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_suKien_quanLyKhachHangVaSuKien)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgv_khachHang_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_timKiem_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.TextBox tb_timKiemKhachHang_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_refreshKhachHang_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_xoaKhachHang_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_capNhatKhachHang_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_themKhachHang_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_diaChi_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_hoVaTen_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_sdt_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgv_suKien_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_timKiemSuKien_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.TextBox tb_timKiemSuKien_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_refreshSuKien_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_xoaSuKien_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_capNhatSuKien_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Button bt_themSuKien_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_giamGia_quanLyKhachHangVaSuKien;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_tenSuKien_quanLyKhachHangVaControl;
        private System.Windows.Forms.Label label10;
    }
}
