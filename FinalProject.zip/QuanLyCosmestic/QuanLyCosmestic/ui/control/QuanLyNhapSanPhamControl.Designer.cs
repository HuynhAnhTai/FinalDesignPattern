﻿namespace QuanLyCosmestic.ui.control
{
    partial class QuanLyNhapSanPhamControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lb_maNhanVien_quanLySanPhamNhanVien = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_sdtNhaCungCap_quanLyNhapSanPham = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_diaChi_quanLyNhapSanPham = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_nhaCungCap_quanLyNhapSanPham = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dtp_ngayNhap_quanLyNhapSanPham = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_gia_quanLyNhapSanPham = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_soLuong_quanLyNhapSanPham = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_maSanPham_quanLyNhapSanPham = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_nhap_quanLyNhapSanPhamControl = new System.Windows.Forms.Button();
            this.bt_xoa_quanLyNhapSanPham = new System.Windows.Forms.Button();
            this.bt_capNhat_quanLyNhapSanPham = new System.Windows.Forms.Button();
            this.bt_refresh_quanLyNhapSanPham = new System.Windows.Forms.Button();
            this.dgv_sanPham_quanLyNhapSanPham = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_sanPham_quanLyNhapSanPham)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lb_maNhanVien_quanLySanPhamNhanVien);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.tb_sdtNhaCungCap_quanLyNhapSanPham);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tb_diaChi_quanLyNhapSanPham);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tb_nhaCungCap_quanLyNhapSanPham);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.dtp_ngayNhap_quanLyNhapSanPham);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tb_gia_quanLyNhapSanPham);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tb_soLuong_quanLyNhapSanPham);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tb_maSanPham_quanLyNhapSanPham);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(934, 138);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin nhập sản phẩm";
            // 
            // lb_maNhanVien_quanLySanPhamNhanVien
            // 
            this.lb_maNhanVien_quanLySanPhamNhanVien.AutoSize = true;
            this.lb_maNhanVien_quanLySanPhamNhanVien.Location = new System.Drawing.Point(107, 27);
            this.lb_maNhanVien_quanLySanPhamNhanVien.Name = "lb_maNhanVien_quanLySanPhamNhanVien";
            this.lb_maNhanVien_quanLySanPhamNhanVien.Size = new System.Drawing.Size(13, 13);
            this.lb_maNhanVien_quanLySanPhamNhanVien.TabIndex = 17;
            this.lb_maNhanVien_quanLySanPhamNhanVien.Text = "1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Mã nhân viên nhập:";
            // 
            // tb_sdtNhaCungCap_quanLyNhapSanPham
            // 
            this.tb_sdtNhaCungCap_quanLyNhapSanPham.Location = new System.Drawing.Point(458, 103);
            this.tb_sdtNhaCungCap_quanLyNhapSanPham.Name = "tb_sdtNhaCungCap_quanLyNhapSanPham";
            this.tb_sdtNhaCungCap_quanLyNhapSanPham.Size = new System.Drawing.Size(168, 20);
            this.tb_sdtNhaCungCap_quanLyNhapSanPham.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(310, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Số điện thoại nhà cung cấp:";
            // 
            // tb_diaChi_quanLyNhapSanPham
            // 
            this.tb_diaChi_quanLyNhapSanPham.Location = new System.Drawing.Point(715, 103);
            this.tb_diaChi_quanLyNhapSanPham.Name = "tb_diaChi_quanLyNhapSanPham";
            this.tb_diaChi_quanLyNhapSanPham.Size = new System.Drawing.Size(206, 20);
            this.tb_diaChi_quanLyNhapSanPham.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(654, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Địa chỉ:";
            // 
            // tb_nhaCungCap_quanLyNhapSanPham
            // 
            this.tb_nhaCungCap_quanLyNhapSanPham.Location = new System.Drawing.Point(90, 103);
            this.tb_nhaCungCap_quanLyNhapSanPham.Name = "tb_nhaCungCap_quanLyNhapSanPham";
            this.tb_nhaCungCap_quanLyNhapSanPham.Size = new System.Drawing.Size(201, 20);
            this.tb_nhaCungCap_quanLyNhapSanPham.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Nhà cung cấp:";
            // 
            // dtp_ngayNhap_quanLyNhapSanPham
            // 
            this.dtp_ngayNhap_quanLyNhapSanPham.Location = new System.Drawing.Point(90, 58);
            this.dtp_ngayNhap_quanLyNhapSanPham.Name = "dtp_ngayNhap_quanLyNhapSanPham";
            this.dtp_ngayNhap_quanLyNhapSanPham.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dtp_ngayNhap_quanLyNhapSanPham.Size = new System.Drawing.Size(201, 20);
            this.dtp_ngayNhap_quanLyNhapSanPham.TabIndex = 8;
            this.dtp_ngayNhap_quanLyNhapSanPham.Value = new System.DateTime(2019, 11, 7, 0, 0, 0, 0);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Ngày nhập:";
            // 
            // tb_gia_quanLyNhapSanPham
            // 
            this.tb_gia_quanLyNhapSanPham.Location = new System.Drawing.Point(715, 58);
            this.tb_gia_quanLyNhapSanPham.Name = "tb_gia_quanLyNhapSanPham";
            this.tb_gia_quanLyNhapSanPham.Size = new System.Drawing.Size(206, 20);
            this.tb_gia_quanLyNhapSanPham.TabIndex = 6;
            this.tb_gia_quanLyNhapSanPham.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_gia_quanLyNhapSanPham_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(654, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Tổng tiền:";
            // 
            // tb_soLuong_quanLyNhapSanPham
            // 
            this.tb_soLuong_quanLyNhapSanPham.Location = new System.Drawing.Point(555, 58);
            this.tb_soLuong_quanLyNhapSanPham.Name = "tb_soLuong_quanLyNhapSanPham";
            this.tb_soLuong_quanLyNhapSanPham.Size = new System.Drawing.Size(71, 20);
            this.tb_soLuong_quanLyNhapSanPham.TabIndex = 4;
            this.tb_soLuong_quanLyNhapSanPham.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_soLuong_quanLyNhapSanPham_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(497, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Số lượng:";
            // 
            // tb_maSanPham_quanLyNhapSanPham
            // 
            this.tb_maSanPham_quanLyNhapSanPham.Location = new System.Drawing.Point(390, 58);
            this.tb_maSanPham_quanLyNhapSanPham.Name = "tb_maSanPham_quanLyNhapSanPham";
            this.tb_maSanPham_quanLyNhapSanPham.Size = new System.Drawing.Size(101, 20);
            this.tb_maSanPham_quanLyNhapSanPham.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(310, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Mã sản phẩm:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thông tin nhập sản phẩm";
            // 
            // bt_nhap_quanLyNhapSanPhamControl
            // 
            this.bt_nhap_quanLyNhapSanPhamControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_nhap_quanLyNhapSanPhamControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_nhap_quanLyNhapSanPhamControl.Location = new System.Drawing.Point(13, 162);
            this.bt_nhap_quanLyNhapSanPhamControl.Name = "bt_nhap_quanLyNhapSanPhamControl";
            this.bt_nhap_quanLyNhapSanPhamControl.Size = new System.Drawing.Size(99, 39);
            this.bt_nhap_quanLyNhapSanPhamControl.TabIndex = 1;
            this.bt_nhap_quanLyNhapSanPhamControl.Text = "Hoàn tất";
            this.bt_nhap_quanLyNhapSanPhamControl.UseVisualStyleBackColor = false;
            this.bt_nhap_quanLyNhapSanPhamControl.Click += new System.EventHandler(this.bt_nhap_quanLyNhapSanPhamControl_Click);
            // 
            // bt_xoa_quanLyNhapSanPham
            // 
            this.bt_xoa_quanLyNhapSanPham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_xoa_quanLyNhapSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_xoa_quanLyNhapSanPham.Location = new System.Drawing.Point(309, 162);
            this.bt_xoa_quanLyNhapSanPham.Name = "bt_xoa_quanLyNhapSanPham";
            this.bt_xoa_quanLyNhapSanPham.Size = new System.Drawing.Size(99, 39);
            this.bt_xoa_quanLyNhapSanPham.TabIndex = 2;
            this.bt_xoa_quanLyNhapSanPham.Text = "Xóa ";
            this.bt_xoa_quanLyNhapSanPham.UseVisualStyleBackColor = false;
            this.bt_xoa_quanLyNhapSanPham.Click += new System.EventHandler(this.bt_xoa_quanLyNhapSanPham_Click);
            // 
            // bt_capNhat_quanLyNhapSanPham
            // 
            this.bt_capNhat_quanLyNhapSanPham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_capNhat_quanLyNhapSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_capNhat_quanLyNhapSanPham.Location = new System.Drawing.Point(159, 162);
            this.bt_capNhat_quanLyNhapSanPham.Name = "bt_capNhat_quanLyNhapSanPham";
            this.bt_capNhat_quanLyNhapSanPham.Size = new System.Drawing.Size(99, 39);
            this.bt_capNhat_quanLyNhapSanPham.TabIndex = 3;
            this.bt_capNhat_quanLyNhapSanPham.Text = "Cập nhật";
            this.bt_capNhat_quanLyNhapSanPham.UseVisualStyleBackColor = false;
            this.bt_capNhat_quanLyNhapSanPham.Click += new System.EventHandler(this.bt_capNhat_quanLyNhapSanPham_Click);
            // 
            // bt_refresh_quanLyNhapSanPham
            // 
            this.bt_refresh_quanLyNhapSanPham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bt_refresh_quanLyNhapSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_refresh_quanLyNhapSanPham.Location = new System.Drawing.Point(453, 162);
            this.bt_refresh_quanLyNhapSanPham.Name = "bt_refresh_quanLyNhapSanPham";
            this.bt_refresh_quanLyNhapSanPham.Size = new System.Drawing.Size(99, 39);
            this.bt_refresh_quanLyNhapSanPham.TabIndex = 4;
            this.bt_refresh_quanLyNhapSanPham.Text = "Refresh";
            this.bt_refresh_quanLyNhapSanPham.UseVisualStyleBackColor = false;
            this.bt_refresh_quanLyNhapSanPham.Click += new System.EventHandler(this.bt_refresh_quanLyNhapSanPham_Click);
            // 
            // dgv_sanPham_quanLyNhapSanPham
            // 
            this.dgv_sanPham_quanLyNhapSanPham.AllowUserToAddRows = false;
            this.dgv_sanPham_quanLyNhapSanPham.AllowUserToDeleteRows = false;
            this.dgv_sanPham_quanLyNhapSanPham.AllowUserToResizeRows = false;
            this.dgv_sanPham_quanLyNhapSanPham.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_sanPham_quanLyNhapSanPham.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgv_sanPham_quanLyNhapSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_sanPham_quanLyNhapSanPham.Location = new System.Drawing.Point(13, 213);
            this.dgv_sanPham_quanLyNhapSanPham.MultiSelect = false;
            this.dgv_sanPham_quanLyNhapSanPham.Name = "dgv_sanPham_quanLyNhapSanPham";
            this.dgv_sanPham_quanLyNhapSanPham.ReadOnly = true;
            this.dgv_sanPham_quanLyNhapSanPham.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_sanPham_quanLyNhapSanPham.Size = new System.Drawing.Size(934, 408);
            this.dgv_sanPham_quanLyNhapSanPham.TabIndex = 5;
            this.dgv_sanPham_quanLyNhapSanPham.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_sanPham_quanLyNhapSanPham_CellClick);
            // 
            // QuanLyNhapSanPhamControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.Controls.Add(this.dgv_sanPham_quanLyNhapSanPham);
            this.Controls.Add(this.bt_refresh_quanLyNhapSanPham);
            this.Controls.Add(this.bt_capNhat_quanLyNhapSanPham);
            this.Controls.Add(this.bt_xoa_quanLyNhapSanPham);
            this.Controls.Add(this.bt_nhap_quanLyNhapSanPhamControl);
            this.Controls.Add(this.groupBox1);
            this.Name = "QuanLyNhapSanPhamControl";
            this.Size = new System.Drawing.Size(950, 636);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_sanPham_quanLyNhapSanPham)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tb_sdtNhaCungCap_quanLyNhapSanPham;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_diaChi_quanLyNhapSanPham;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_nhaCungCap_quanLyNhapSanPham;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtp_ngayNhap_quanLyNhapSanPham;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_gia_quanLyNhapSanPham;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_soLuong_quanLyNhapSanPham;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_maSanPham_quanLyNhapSanPham;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lb_maNhanVien_quanLySanPhamNhanVien;
        private System.Windows.Forms.Button bt_nhap_quanLyNhapSanPhamControl;
        private System.Windows.Forms.Button bt_xoa_quanLyNhapSanPham;
        private System.Windows.Forms.Button bt_capNhat_quanLyNhapSanPham;
        private System.Windows.Forms.Button bt_refresh_quanLyNhapSanPham;
        private System.Windows.Forms.DataGridView dgv_sanPham_quanLyNhapSanPham;
    }
}
