﻿namespace QuanLyCosmestic.ui
{
    partial class QuanLyNhanVien
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gb_thongTinCaNhan_quanLyNhanVienControl = new System.Windows.Forms.GroupBox();
            this.tb_sdt_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_email_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.tb_diaChi_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.tb_cmnd_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.dtp_ngaySinh_quanLyNhanVienControl = new System.Windows.Forms.DateTimePicker();
            this.rb_gioiTinh_nu_quanLyNhanVienControl = new System.Windows.Forms.RadioButton();
            this.rb_gioiTinh_nam_quanLyNhanVienControl = new System.Windows.Forms.RadioButton();
            this.tb_hoTen_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.lb_email_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_diaChi_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_cmnd_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_ngaySinh_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_gioiTinh_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_name_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_luong_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.cb_caLam_quanLyNhanVienControl = new System.Windows.Forms.ComboBox();
            this.cb_chucVu_quanLyNhanVienControl = new System.Windows.Forms.ComboBox();
            this.dtp_ngayVaoLam_quanLyNhanVienControl = new System.Windows.Forms.DateTimePicker();
            this.tb_password_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.tb_userName_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.lb_password_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_luong_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_caTruc_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_chucVu_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_ngayVaoLam_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.lb_userName_quanLyNhanVienControl = new System.Windows.Forms.Label();
            this.dtg_nhanVien_quanLyNhanVienControl = new System.Windows.Forms.DataGridView();
            this.tb_timKiemNhanVien_quanLyNhanVienControl = new System.Windows.Forms.TextBox();
            this.bt_findNhanVien_quanLyNhanVienControl = new System.Windows.Forms.Button();
            this.bt_themNhanVien_quanLyNhanVienControl = new System.Windows.Forms.Button();
            this.bt_capNhatNhanVien_quanLyNhanVienControl = new System.Windows.Forms.Button();
            this.bt_xoaNhanVien_quanLyNhanVienControl = new System.Windows.Forms.Button();
            this.bt_refresh_quanLyNhanVienControl = new System.Windows.Forms.Button();
            this.gb_thongTinCaNhan_quanLyNhanVienControl.SuspendLayout();
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_nhanVien_quanLyNhanVienControl)).BeginInit();
            this.SuspendLayout();
            // 
            // gb_thongTinCaNhan_quanLyNhanVienControl
            // 
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.tb_sdt_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.label3);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.label1);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.tb_email_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.tb_diaChi_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.tb_cmnd_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.dtp_ngaySinh_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.rb_gioiTinh_nu_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.rb_gioiTinh_nam_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.tb_hoTen_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.lb_email_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.lb_diaChi_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.lb_cmnd_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.lb_ngaySinh_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.lb_gioiTinh_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Controls.Add(this.lb_name_quanLyNhanVienControl);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Location = new System.Drawing.Point(20, 26);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Name = "gb_thongTinCaNhan_quanLyNhanVienControl";
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Size = new System.Drawing.Size(377, 231);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.TabIndex = 25;
            this.gb_thongTinCaNhan_quanLyNhanVienControl.TabStop = false;
            this.gb_thongTinCaNhan_quanLyNhanVienControl.Text = "Thông tin cá nhân";
            // 
            // tb_sdt_quanLyNhanVienControl
            // 
            this.tb_sdt_quanLyNhanVienControl.Location = new System.Drawing.Point(103, 169);
            this.tb_sdt_quanLyNhanVienControl.Name = "tb_sdt_quanLyNhanVienControl";
            this.tb_sdt_quanLyNhanVienControl.Size = new System.Drawing.Size(258, 20);
            this.tb_sdt_quanLyNhanVienControl.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "Số điện thoại:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 37;
            this.label1.Text = "Thông tin cá nhân";
            // 
            // tb_email_quanLyNhanVienControl
            // 
            this.tb_email_quanLyNhanVienControl.Location = new System.Drawing.Point(103, 199);
            this.tb_email_quanLyNhanVienControl.Name = "tb_email_quanLyNhanVienControl";
            this.tb_email_quanLyNhanVienControl.Size = new System.Drawing.Size(258, 20);
            this.tb_email_quanLyNhanVienControl.TabIndex = 33;
            // 
            // tb_diaChi_quanLyNhanVienControl
            // 
            this.tb_diaChi_quanLyNhanVienControl.Location = new System.Drawing.Point(103, 139);
            this.tb_diaChi_quanLyNhanVienControl.Name = "tb_diaChi_quanLyNhanVienControl";
            this.tb_diaChi_quanLyNhanVienControl.Size = new System.Drawing.Size(258, 20);
            this.tb_diaChi_quanLyNhanVienControl.TabIndex = 32;
            // 
            // tb_cmnd_quanLyNhanVienControl
            // 
            this.tb_cmnd_quanLyNhanVienControl.Location = new System.Drawing.Point(103, 109);
            this.tb_cmnd_quanLyNhanVienControl.Name = "tb_cmnd_quanLyNhanVienControl";
            this.tb_cmnd_quanLyNhanVienControl.Size = new System.Drawing.Size(258, 20);
            this.tb_cmnd_quanLyNhanVienControl.TabIndex = 31;
            this.tb_cmnd_quanLyNhanVienControl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_cmnd_quanLyNhanVienControl_KeyPress);
            // 
            // dtp_ngaySinh_quanLyNhanVienControl
            // 
            this.dtp_ngaySinh_quanLyNhanVienControl.Location = new System.Drawing.Point(103, 76);
            this.dtp_ngaySinh_quanLyNhanVienControl.Name = "dtp_ngaySinh_quanLyNhanVienControl";
            this.dtp_ngaySinh_quanLyNhanVienControl.Size = new System.Drawing.Size(258, 20);
            this.dtp_ngaySinh_quanLyNhanVienControl.TabIndex = 30;
            // 
            // rb_gioiTinh_nu_quanLyNhanVienControl
            // 
            this.rb_gioiTinh_nu_quanLyNhanVienControl.AutoSize = true;
            this.rb_gioiTinh_nu_quanLyNhanVienControl.Location = new System.Drawing.Point(166, 47);
            this.rb_gioiTinh_nu_quanLyNhanVienControl.Name = "rb_gioiTinh_nu_quanLyNhanVienControl";
            this.rb_gioiTinh_nu_quanLyNhanVienControl.Size = new System.Drawing.Size(39, 17);
            this.rb_gioiTinh_nu_quanLyNhanVienControl.TabIndex = 29;
            this.rb_gioiTinh_nu_quanLyNhanVienControl.TabStop = true;
            this.rb_gioiTinh_nu_quanLyNhanVienControl.Text = "Nữ";
            this.rb_gioiTinh_nu_quanLyNhanVienControl.UseVisualStyleBackColor = true;
            // 
            // rb_gioiTinh_nam_quanLyNhanVienControl
            // 
            this.rb_gioiTinh_nam_quanLyNhanVienControl.AutoSize = true;
            this.rb_gioiTinh_nam_quanLyNhanVienControl.Location = new System.Drawing.Point(103, 47);
            this.rb_gioiTinh_nam_quanLyNhanVienControl.Name = "rb_gioiTinh_nam_quanLyNhanVienControl";
            this.rb_gioiTinh_nam_quanLyNhanVienControl.Size = new System.Drawing.Size(47, 17);
            this.rb_gioiTinh_nam_quanLyNhanVienControl.TabIndex = 28;
            this.rb_gioiTinh_nam_quanLyNhanVienControl.TabStop = true;
            this.rb_gioiTinh_nam_quanLyNhanVienControl.Text = "Nam";
            this.rb_gioiTinh_nam_quanLyNhanVienControl.UseVisualStyleBackColor = true;
            // 
            // tb_hoTen_quanLyNhanVienControl
            // 
            this.tb_hoTen_quanLyNhanVienControl.Location = new System.Drawing.Point(103, 16);
            this.tb_hoTen_quanLyNhanVienControl.Name = "tb_hoTen_quanLyNhanVienControl";
            this.tb_hoTen_quanLyNhanVienControl.Size = new System.Drawing.Size(258, 20);
            this.tb_hoTen_quanLyNhanVienControl.TabIndex = 27;
            // 
            // lb_email_quanLyNhanVienControl
            // 
            this.lb_email_quanLyNhanVienControl.AutoSize = true;
            this.lb_email_quanLyNhanVienControl.Location = new System.Drawing.Point(17, 206);
            this.lb_email_quanLyNhanVienControl.Name = "lb_email_quanLyNhanVienControl";
            this.lb_email_quanLyNhanVienControl.Size = new System.Drawing.Size(35, 13);
            this.lb_email_quanLyNhanVienControl.TabIndex = 26;
            this.lb_email_quanLyNhanVienControl.Text = "Email:";
            // 
            // lb_diaChi_quanLyNhanVienControl
            // 
            this.lb_diaChi_quanLyNhanVienControl.AutoSize = true;
            this.lb_diaChi_quanLyNhanVienControl.Location = new System.Drawing.Point(17, 147);
            this.lb_diaChi_quanLyNhanVienControl.Name = "lb_diaChi_quanLyNhanVienControl";
            this.lb_diaChi_quanLyNhanVienControl.Size = new System.Drawing.Size(44, 13);
            this.lb_diaChi_quanLyNhanVienControl.TabIndex = 25;
            this.lb_diaChi_quanLyNhanVienControl.Text = "Địa Chỉ:";
            // 
            // lb_cmnd_quanLyNhanVienControl
            // 
            this.lb_cmnd_quanLyNhanVienControl.AutoSize = true;
            this.lb_cmnd_quanLyNhanVienControl.Location = new System.Drawing.Point(17, 114);
            this.lb_cmnd_quanLyNhanVienControl.Name = "lb_cmnd_quanLyNhanVienControl";
            this.lb_cmnd_quanLyNhanVienControl.Size = new System.Drawing.Size(42, 13);
            this.lb_cmnd_quanLyNhanVienControl.TabIndex = 24;
            this.lb_cmnd_quanLyNhanVienControl.Text = "CMND:";
            // 
            // lb_ngaySinh_quanLyNhanVienControl
            // 
            this.lb_ngaySinh_quanLyNhanVienControl.AutoSize = true;
            this.lb_ngaySinh_quanLyNhanVienControl.Location = new System.Drawing.Point(17, 82);
            this.lb_ngaySinh_quanLyNhanVienControl.Name = "lb_ngaySinh_quanLyNhanVienControl";
            this.lb_ngaySinh_quanLyNhanVienControl.Size = new System.Drawing.Size(59, 13);
            this.lb_ngaySinh_quanLyNhanVienControl.TabIndex = 23;
            this.lb_ngaySinh_quanLyNhanVienControl.Text = "Ngày Sinh:";
            // 
            // lb_gioiTinh_quanLyNhanVienControl
            // 
            this.lb_gioiTinh_quanLyNhanVienControl.AutoSize = true;
            this.lb_gioiTinh_quanLyNhanVienControl.Location = new System.Drawing.Point(17, 50);
            this.lb_gioiTinh_quanLyNhanVienControl.Name = "lb_gioiTinh_quanLyNhanVienControl";
            this.lb_gioiTinh_quanLyNhanVienControl.Size = new System.Drawing.Size(54, 13);
            this.lb_gioiTinh_quanLyNhanVienControl.TabIndex = 22;
            this.lb_gioiTinh_quanLyNhanVienControl.Text = "Giới Tính:";
            // 
            // lb_name_quanLyNhanVienControl
            // 
            this.lb_name_quanLyNhanVienControl.AutoSize = true;
            this.lb_name_quanLyNhanVienControl.Location = new System.Drawing.Point(17, 23);
            this.lb_name_quanLyNhanVienControl.Name = "lb_name_quanLyNhanVienControl";
            this.lb_name_quanLyNhanVienControl.Size = new System.Drawing.Size(46, 13);
            this.lb_name_quanLyNhanVienControl.TabIndex = 21;
            this.lb_name_quanLyNhanVienControl.Text = "Họ Tên:";
            // 
            // gb_thongTinTaiKhoan_quanLyNhanVienControl
            // 
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.label2);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.tb_luong_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.cb_caLam_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.cb_chucVu_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.dtp_ngayVaoLam_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.tb_password_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.tb_userName_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.lb_password_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.lb_luong_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.lb_caTruc_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.lb_chucVu_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.lb_ngayVaoLam_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Controls.Add(this.lb_userName_quanLyNhanVienControl);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Location = new System.Drawing.Point(544, 26);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Name = "gb_thongTinTaiKhoan_quanLyNhanVienControl";
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Size = new System.Drawing.Size(324, 231);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.TabIndex = 26;
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.TabStop = false;
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.Text = "Thông tin tài khoản";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Thông tin tài khoản";
            // 
            // tb_luong_quanLyNhanVienControl
            // 
            this.tb_luong_quanLyNhanVienControl.Location = new System.Drawing.Point(115, 176);
            this.tb_luong_quanLyNhanVienControl.Name = "tb_luong_quanLyNhanVienControl";
            this.tb_luong_quanLyNhanVienControl.Size = new System.Drawing.Size(199, 20);
            this.tb_luong_quanLyNhanVienControl.TabIndex = 36;
            this.tb_luong_quanLyNhanVienControl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_luong_quanLyNhanVienControl_KeyPress);
            // 
            // cb_caLam_quanLyNhanVienControl
            // 
            this.cb_caLam_quanLyNhanVienControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_caLam_quanLyNhanVienControl.FormattingEnabled = true;
            this.cb_caLam_quanLyNhanVienControl.Items.AddRange(new object[] {
            "C1",
            "C2",
            "C3",
            "FULLTIME"});
            this.cb_caLam_quanLyNhanVienControl.Location = new System.Drawing.Point(115, 144);
            this.cb_caLam_quanLyNhanVienControl.Name = "cb_caLam_quanLyNhanVienControl";
            this.cb_caLam_quanLyNhanVienControl.Size = new System.Drawing.Size(199, 21);
            this.cb_caLam_quanLyNhanVienControl.TabIndex = 35;
            // 
            // cb_chucVu_quanLyNhanVienControl
            // 
            this.cb_chucVu_quanLyNhanVienControl.DropDownHeight = 50;
            this.cb_chucVu_quanLyNhanVienControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_chucVu_quanLyNhanVienControl.FormattingEnabled = true;
            this.cb_chucVu_quanLyNhanVienControl.IntegralHeight = false;
            this.cb_chucVu_quanLyNhanVienControl.Items.AddRange(new object[] {
            "Quản lý",
            "Nhân viên bán hàng",
            "Nhân viên kho"});
            this.cb_chucVu_quanLyNhanVienControl.Location = new System.Drawing.Point(115, 114);
            this.cb_chucVu_quanLyNhanVienControl.Name = "cb_chucVu_quanLyNhanVienControl";
            this.cb_chucVu_quanLyNhanVienControl.Size = new System.Drawing.Size(199, 21);
            this.cb_chucVu_quanLyNhanVienControl.TabIndex = 34;
            // 
            // dtp_ngayVaoLam_quanLyNhanVienControl
            // 
            this.dtp_ngayVaoLam_quanLyNhanVienControl.Location = new System.Drawing.Point(115, 81);
            this.dtp_ngayVaoLam_quanLyNhanVienControl.Name = "dtp_ngayVaoLam_quanLyNhanVienControl";
            this.dtp_ngayVaoLam_quanLyNhanVienControl.Size = new System.Drawing.Size(199, 20);
            this.dtp_ngayVaoLam_quanLyNhanVienControl.TabIndex = 33;
            // 
            // tb_password_quanLyNhanVienControl
            // 
            this.tb_password_quanLyNhanVienControl.Location = new System.Drawing.Point(115, 47);
            this.tb_password_quanLyNhanVienControl.Name = "tb_password_quanLyNhanVienControl";
            this.tb_password_quanLyNhanVienControl.Size = new System.Drawing.Size(199, 20);
            this.tb_password_quanLyNhanVienControl.TabIndex = 32;
            // 
            // tb_userName_quanLyNhanVienControl
            // 
            this.tb_userName_quanLyNhanVienControl.Location = new System.Drawing.Point(115, 14);
            this.tb_userName_quanLyNhanVienControl.Name = "tb_userName_quanLyNhanVienControl";
            this.tb_userName_quanLyNhanVienControl.Size = new System.Drawing.Size(199, 20);
            this.tb_userName_quanLyNhanVienControl.TabIndex = 31;
            // 
            // lb_password_quanLyNhanVienControl
            // 
            this.lb_password_quanLyNhanVienControl.AutoSize = true;
            this.lb_password_quanLyNhanVienControl.Location = new System.Drawing.Point(9, 54);
            this.lb_password_quanLyNhanVienControl.Name = "lb_password_quanLyNhanVienControl";
            this.lb_password_quanLyNhanVienControl.Size = new System.Drawing.Size(56, 13);
            this.lb_password_quanLyNhanVienControl.TabIndex = 30;
            this.lb_password_quanLyNhanVienControl.Text = "Password:";
            // 
            // lb_luong_quanLyNhanVienControl
            // 
            this.lb_luong_quanLyNhanVienControl.AutoSize = true;
            this.lb_luong_quanLyNhanVienControl.Location = new System.Drawing.Point(9, 179);
            this.lb_luong_quanLyNhanVienControl.Name = "lb_luong_quanLyNhanVienControl";
            this.lb_luong_quanLyNhanVienControl.Size = new System.Drawing.Size(40, 13);
            this.lb_luong_quanLyNhanVienControl.TabIndex = 29;
            this.lb_luong_quanLyNhanVienControl.Text = "Lương:";
            // 
            // lb_caTruc_quanLyNhanVienControl
            // 
            this.lb_caTruc_quanLyNhanVienControl.AutoSize = true;
            this.lb_caTruc_quanLyNhanVienControl.Location = new System.Drawing.Point(9, 147);
            this.lb_caTruc_quanLyNhanVienControl.Name = "lb_caTruc_quanLyNhanVienControl";
            this.lb_caTruc_quanLyNhanVienControl.Size = new System.Drawing.Size(46, 13);
            this.lb_caTruc_quanLyNhanVienControl.TabIndex = 28;
            this.lb_caTruc_quanLyNhanVienControl.Text = "Ca Làm:";
            // 
            // lb_chucVu_quanLyNhanVienControl
            // 
            this.lb_chucVu_quanLyNhanVienControl.AutoSize = true;
            this.lb_chucVu_quanLyNhanVienControl.Location = new System.Drawing.Point(9, 117);
            this.lb_chucVu_quanLyNhanVienControl.Name = "lb_chucVu_quanLyNhanVienControl";
            this.lb_chucVu_quanLyNhanVienControl.Size = new System.Drawing.Size(50, 13);
            this.lb_chucVu_quanLyNhanVienControl.TabIndex = 27;
            this.lb_chucVu_quanLyNhanVienControl.Text = "Chức vụ:";
            // 
            // lb_ngayVaoLam_quanLyNhanVienControl
            // 
            this.lb_ngayVaoLam_quanLyNhanVienControl.AutoSize = true;
            this.lb_ngayVaoLam_quanLyNhanVienControl.Location = new System.Drawing.Point(9, 87);
            this.lb_ngayVaoLam_quanLyNhanVienControl.Name = "lb_ngayVaoLam_quanLyNhanVienControl";
            this.lb_ngayVaoLam_quanLyNhanVienControl.Size = new System.Drawing.Size(80, 13);
            this.lb_ngayVaoLam_quanLyNhanVienControl.TabIndex = 26;
            this.lb_ngayVaoLam_quanLyNhanVienControl.Text = "Ngày Vào Làm:";
            // 
            // lb_userName_quanLyNhanVienControl
            // 
            this.lb_userName_quanLyNhanVienControl.AutoSize = true;
            this.lb_userName_quanLyNhanVienControl.Location = new System.Drawing.Point(9, 19);
            this.lb_userName_quanLyNhanVienControl.Name = "lb_userName_quanLyNhanVienControl";
            this.lb_userName_quanLyNhanVienControl.Size = new System.Drawing.Size(63, 13);
            this.lb_userName_quanLyNhanVienControl.TabIndex = 25;
            this.lb_userName_quanLyNhanVienControl.Text = "User Name:";
            // 
            // dtg_nhanVien_quanLyNhanVienControl
            // 
            this.dtg_nhanVien_quanLyNhanVienControl.AllowUserToAddRows = false;
            this.dtg_nhanVien_quanLyNhanVienControl.AllowUserToDeleteRows = false;
            this.dtg_nhanVien_quanLyNhanVienControl.AllowUserToResizeRows = false;
            this.dtg_nhanVien_quanLyNhanVienControl.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtg_nhanVien_quanLyNhanVienControl.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtg_nhanVien_quanLyNhanVienControl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_nhanVien_quanLyNhanVienControl.Location = new System.Drawing.Point(20, 299);
            this.dtg_nhanVien_quanLyNhanVienControl.MultiSelect = false;
            this.dtg_nhanVien_quanLyNhanVienControl.Name = "dtg_nhanVien_quanLyNhanVienControl";
            this.dtg_nhanVien_quanLyNhanVienControl.ReadOnly = true;
            this.dtg_nhanVien_quanLyNhanVienControl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dtg_nhanVien_quanLyNhanVienControl.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtg_nhanVien_quanLyNhanVienControl.Size = new System.Drawing.Size(911, 334);
            this.dtg_nhanVien_quanLyNhanVienControl.TabIndex = 27;
            this.dtg_nhanVien_quanLyNhanVienControl.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtg_nhanVien_quanLyNhanVienControl_CellClick);
            // 
            // tb_timKiemNhanVien_quanLyNhanVienControl
            // 
            this.tb_timKiemNhanVien_quanLyNhanVienControl.Location = new System.Drawing.Point(20, 273);
            this.tb_timKiemNhanVien_quanLyNhanVienControl.Name = "tb_timKiemNhanVien_quanLyNhanVienControl";
            this.tb_timKiemNhanVien_quanLyNhanVienControl.Size = new System.Drawing.Size(291, 20);
            this.tb_timKiemNhanVien_quanLyNhanVienControl.TabIndex = 29;
            this.tb_timKiemNhanVien_quanLyNhanVienControl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_timKiemNhanVien_quanLyNhanVienControl_KeyDown);
            // 
            // bt_findNhanVien_quanLyNhanVienControl
            // 
            this.bt_findNhanVien_quanLyNhanVienControl.Location = new System.Drawing.Point(322, 270);
            this.bt_findNhanVien_quanLyNhanVienControl.Name = "bt_findNhanVien_quanLyNhanVienControl";
            this.bt_findNhanVien_quanLyNhanVienControl.Size = new System.Drawing.Size(75, 23);
            this.bt_findNhanVien_quanLyNhanVienControl.TabIndex = 30;
            this.bt_findNhanVien_quanLyNhanVienControl.Text = "Tìm kiếm";
            this.bt_findNhanVien_quanLyNhanVienControl.UseVisualStyleBackColor = true;
            this.bt_findNhanVien_quanLyNhanVienControl.Click += new System.EventHandler(this.bt_findNhanVien_quanLyNhanVienControl_Click);
            // 
            // bt_themNhanVien_quanLyNhanVienControl
            // 
            this.bt_themNhanVien_quanLyNhanVienControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_themNhanVien_quanLyNhanVienControl.Location = new System.Drawing.Point(539, 270);
            this.bt_themNhanVien_quanLyNhanVienControl.Name = "bt_themNhanVien_quanLyNhanVienControl";
            this.bt_themNhanVien_quanLyNhanVienControl.Size = new System.Drawing.Size(75, 23);
            this.bt_themNhanVien_quanLyNhanVienControl.TabIndex = 31;
            this.bt_themNhanVien_quanLyNhanVienControl.Text = "Thêm";
            this.bt_themNhanVien_quanLyNhanVienControl.UseVisualStyleBackColor = false;
            this.bt_themNhanVien_quanLyNhanVienControl.Click += new System.EventHandler(this.bt_themNhanVien_quanLyNhanVienControl_Click);
            // 
            // bt_capNhatNhanVien_quanLyNhanVienControl
            // 
            this.bt_capNhatNhanVien_quanLyNhanVienControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_capNhatNhanVien_quanLyNhanVienControl.Location = new System.Drawing.Point(621, 270);
            this.bt_capNhatNhanVien_quanLyNhanVienControl.Name = "bt_capNhatNhanVien_quanLyNhanVienControl";
            this.bt_capNhatNhanVien_quanLyNhanVienControl.Size = new System.Drawing.Size(75, 23);
            this.bt_capNhatNhanVien_quanLyNhanVienControl.TabIndex = 32;
            this.bt_capNhatNhanVien_quanLyNhanVienControl.Text = "Cập nhật";
            this.bt_capNhatNhanVien_quanLyNhanVienControl.UseVisualStyleBackColor = false;
            this.bt_capNhatNhanVien_quanLyNhanVienControl.Click += new System.EventHandler(this.bt_capNhatNhanVien_quanLyNhanVienControl_Click);
            // 
            // bt_xoaNhanVien_quanLyNhanVienControl
            // 
            this.bt_xoaNhanVien_quanLyNhanVienControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bt_xoaNhanVien_quanLyNhanVienControl.Location = new System.Drawing.Point(702, 270);
            this.bt_xoaNhanVien_quanLyNhanVienControl.Name = "bt_xoaNhanVien_quanLyNhanVienControl";
            this.bt_xoaNhanVien_quanLyNhanVienControl.Size = new System.Drawing.Size(75, 23);
            this.bt_xoaNhanVien_quanLyNhanVienControl.TabIndex = 33;
            this.bt_xoaNhanVien_quanLyNhanVienControl.Text = "Xóa";
            this.bt_xoaNhanVien_quanLyNhanVienControl.UseVisualStyleBackColor = false;
            this.bt_xoaNhanVien_quanLyNhanVienControl.Click += new System.EventHandler(this.bt_xoaNhanVien_quanLyNhanVienControl_Click);
            // 
            // bt_refresh_quanLyNhanVienControl
            // 
            this.bt_refresh_quanLyNhanVienControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bt_refresh_quanLyNhanVienControl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_refresh_quanLyNhanVienControl.Location = new System.Drawing.Point(783, 270);
            this.bt_refresh_quanLyNhanVienControl.Name = "bt_refresh_quanLyNhanVienControl";
            this.bt_refresh_quanLyNhanVienControl.Size = new System.Drawing.Size(75, 23);
            this.bt_refresh_quanLyNhanVienControl.TabIndex = 34;
            this.bt_refresh_quanLyNhanVienControl.Text = "Refresh";
            this.bt_refresh_quanLyNhanVienControl.UseVisualStyleBackColor = false;
            this.bt_refresh_quanLyNhanVienControl.Click += new System.EventHandler(this.bt_refresh_quanLyNhanVienControl_Click);
            // 
            // QuanLyNhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.Controls.Add(this.bt_refresh_quanLyNhanVienControl);
            this.Controls.Add(this.bt_xoaNhanVien_quanLyNhanVienControl);
            this.Controls.Add(this.bt_capNhatNhanVien_quanLyNhanVienControl);
            this.Controls.Add(this.bt_themNhanVien_quanLyNhanVienControl);
            this.Controls.Add(this.bt_findNhanVien_quanLyNhanVienControl);
            this.Controls.Add(this.tb_timKiemNhanVien_quanLyNhanVienControl);
            this.Controls.Add(this.dtg_nhanVien_quanLyNhanVienControl);
            this.Controls.Add(this.gb_thongTinTaiKhoan_quanLyNhanVienControl);
            this.Controls.Add(this.gb_thongTinCaNhan_quanLyNhanVienControl);
            this.Name = "QuanLyNhanVien";
            this.Size = new System.Drawing.Size(950, 636);
            this.Load += new System.EventHandler(this.QuanLyNhanVien_Load);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.ResumeLayout(false);
            this.gb_thongTinCaNhan_quanLyNhanVienControl.PerformLayout();
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.ResumeLayout(false);
            this.gb_thongTinTaiKhoan_quanLyNhanVienControl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_nhanVien_quanLyNhanVienControl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_thongTinCaNhan_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_email_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_diaChi_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_cmnd_quanLyNhanVienControl;
        private System.Windows.Forms.DateTimePicker dtp_ngaySinh_quanLyNhanVienControl;
        private System.Windows.Forms.RadioButton rb_gioiTinh_nu_quanLyNhanVienControl;
        private System.Windows.Forms.RadioButton rb_gioiTinh_nam_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_hoTen_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_email_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_diaChi_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_cmnd_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_ngaySinh_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_gioiTinh_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_name_quanLyNhanVienControl;
        private System.Windows.Forms.GroupBox gb_thongTinTaiKhoan_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_luong_quanLyNhanVienControl;
        private System.Windows.Forms.ComboBox cb_caLam_quanLyNhanVienControl;
        private System.Windows.Forms.ComboBox cb_chucVu_quanLyNhanVienControl;
        private System.Windows.Forms.DateTimePicker dtp_ngayVaoLam_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_password_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_userName_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_password_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_luong_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_caTruc_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_chucVu_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_ngayVaoLam_quanLyNhanVienControl;
        private System.Windows.Forms.Label lb_userName_quanLyNhanVienControl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dtg_nhanVien_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_timKiemNhanVien_quanLyNhanVienControl;
        private System.Windows.Forms.Button bt_findNhanVien_quanLyNhanVienControl;
        private System.Windows.Forms.Button bt_themNhanVien_quanLyNhanVienControl;
        private System.Windows.Forms.Button bt_capNhatNhanVien_quanLyNhanVienControl;
        private System.Windows.Forms.Button bt_xoaNhanVien_quanLyNhanVienControl;
        private System.Windows.Forms.Button bt_refresh_quanLyNhanVienControl;
        private System.Windows.Forms.TextBox tb_sdt_quanLyNhanVienControl;
        private System.Windows.Forms.Label label3;
    }
}
