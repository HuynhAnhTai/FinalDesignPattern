﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyCosmestic.ui.command
{
    abstract class CommandButtonManagement
    {
        public abstract void adjustItem();

        public abstract void notAdjustItem();
    }
}
