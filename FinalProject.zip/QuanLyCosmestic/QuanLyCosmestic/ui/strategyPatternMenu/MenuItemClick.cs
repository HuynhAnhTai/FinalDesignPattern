﻿using QuanLyCosmestic.ui.templatePattern;

namespace QuanLyCosmestic.ui.strategyPatternMenu
{
    interface MenuItemClick
    {
        void clickScreen(ControlScreen control);
        void fristActive(ControlScreen control);
    }
}
