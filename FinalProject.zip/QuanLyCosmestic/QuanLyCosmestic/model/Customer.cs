﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyCosmestic.model
{
    class Customer
    {
        public Customer()
        {

        }

        public String phone_customer { get; set; }

        public String name_customer { get; set; }

        public String address_customer { get; set; }
    }
}
