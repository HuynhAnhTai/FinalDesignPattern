﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyCosmestic.model
{
    class Role
    {
        public Role()
        {

        }

        public String name_role { get; set; }
    }
}
