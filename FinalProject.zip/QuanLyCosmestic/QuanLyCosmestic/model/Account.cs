﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyCosmestic.model
{
    class Account
    {
        public Account()
        {

        }

        public String user_name { get; set; }

        public String password { get; set; }
    }
}
