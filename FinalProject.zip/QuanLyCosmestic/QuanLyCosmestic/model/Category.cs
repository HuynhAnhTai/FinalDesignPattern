﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyCosmestic.model
{
    class Category
    {
        public Category()
        {

        }

        public int id_category { get; set; }

        public String name_category { get; set; }
    }
}
